package com.oe.mapper;

public interface SellBoardMapper {

}
