package com.oe.mapper;

public interface HeartBoardMapper {

}
