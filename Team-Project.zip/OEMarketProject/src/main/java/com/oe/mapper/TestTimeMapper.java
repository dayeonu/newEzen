package com.oe.mapper;

public interface TestTimeMapper {

	public String getTime();
	
}
