package com.oe.mapper;

public interface MarketBoardMapper {

}
