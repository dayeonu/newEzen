package com.oe.mapper;

public interface MarketUserMapper {

}
