package com.oe.mapper;

public interface MyPageMapper {

}
