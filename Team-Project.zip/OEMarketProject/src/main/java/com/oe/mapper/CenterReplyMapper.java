package com.oe.mapper;

public interface CenterReplyMapper {

}
