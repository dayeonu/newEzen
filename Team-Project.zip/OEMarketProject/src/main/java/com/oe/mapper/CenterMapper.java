package com.oe.mapper;

public interface CenterMapper {

}
