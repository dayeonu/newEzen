* 참조 및 진행 흔적 폴더에는 그 동안 만들었던 계획서나 ppt가 있습니다.

* 앞에 붙은 숫자는 날짜입니다.

* 디자인 파일은 01부터 순서대로 봐주시면 됩니다. 어디까지나 참고용.
 디자인은 언제든 변경 가능합니다.


*OEMarketProject - 이번 포폴에서 공유되야할 가장 기본만 적혀있는
 프로젝트. 만들어야할 빈 깡통으로 여기부터 다같이 시작.

	com.oe.mapper 패키지 속 TestTimeMapper.java 와 
	src/main/resource 폴더의 com/oe/mapper TestTimeMapper.xml, 
	src/test/java 폴더의 org.zerock.persistence 패키지 속 TestTimeMapperTests.java, JDBCTests.java 클래스는
	jdbc나 mapper 등의 첫 연동확인을 위해 작성한 것이니 신경쓰지 않으셔도 됩니다.


*OEMarket01 - 메인페이지 HTML/CSS소스와 로그인 페이지, 
			JS가 일부 적용된 회원가입(유효성 체크 - 아이디를 입력해주세요) 폼만 있습니다.

*OEMarket2 - 기욱 작업중인 프로젝트(신경쓸필요없음)