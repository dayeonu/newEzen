package com.oe.controller;

public class BuyBoardController {

}
