package com.oe.mapper;

public class MarketUserMapper {

}
