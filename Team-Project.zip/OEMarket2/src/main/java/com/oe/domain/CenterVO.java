package com.oe.domain;

public class CenterVO {

}
