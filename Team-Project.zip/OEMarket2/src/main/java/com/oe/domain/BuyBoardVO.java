package com.oe.domain;

public class BuyBoardVO {

}
