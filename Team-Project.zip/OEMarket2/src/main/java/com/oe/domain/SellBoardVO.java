package com.oe.domain;

public class SellBoardVO {

}
