package com.oe.domain;

public class MarketBoardVO {

}
